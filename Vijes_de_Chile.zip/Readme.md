## Prueba Viajes de Chile
## Este en un proyecto dentro del marco del curso Full-Stack JavaSripct Treinee.

### Repositorio
- [https://github.com/Carlopitecus/Viajes-de-Chile] (https://github.com/Carlopitecus/Viajes-de-Chile)

### Git-pages
- [https://carlopitecus.github.io/Viajes-de-Chile/#] (https://carlopitecus.github.io/Viajes-de-Chile/#)


- Es la primera prueba que comprende las unidades de HTML, CSS, Bootstrap y gitHub.
- La version de HTML es la versión 5
- La version de Bootstrap usada es la 4.5.
- La versión de fontawesome usada es la v5.6.3

#### El codigo:
- NavBar: le puse una clase "position: absolute" para que se situé sobre el carrusel, ademas de no tener color de fondo con lo que adopta el de la imagen que esta pasando en ese momento el "carousel".
- La seccion desaparece en el tamño de pantalla más pequeño con la clase de Bootstrap d-none
- La fuente es la Raleway sacada de Googlefont

#### Las Clases
Se usan clases tando de Bootstrap como propias.
- Las clases propias siguen la metodología BEM, Bloque__Elemento--modificador.
- se usa es selector universal "*" para resetear el "margin" y el "padding" de la pagína.




